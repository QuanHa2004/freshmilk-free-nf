<?php
require_once __DIR__ . '/AuthRoutes.php';
require_once __DIR__ . '/CustomerRoutes.php';
require_once __DIR__ . '/AdminRoutes.php';